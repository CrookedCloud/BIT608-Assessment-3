<!--Sky Reekie SN#3809237 BIT608 Assesment 2-->
<?php
session_start();
session_destroy();
header("Location: login.php");
exit();
?>
