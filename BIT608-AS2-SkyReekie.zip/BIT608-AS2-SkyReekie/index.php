<!--Sky Reekie SN#3809237 BIT608 Assesment 2-->
<!--Doctype and Language-->
<!DOCTYPE html>
<html lang="en">
<!--Set the page title-->
<head>
    <title>homepage.html</title>
    <meta charset="utf-8">
</head>

<!--------------------------------->
<!--Basic homepage has been added to test the links in other pages-->
<!--------------------------------->

<body>
    <h1>Home Page<br></h1>
    <a href="../BIT608-AS2-SkyReekie/Login.php" style="font-size: 20px; padding-top: 0px; line-height: 2;">[Login]<br></a>
    <a href="../BIT608-AS2-SkyReekie/NewCustomer.php" style="font-size: 20px; padding-top: 0px; line-height: 2;">[[New Customer]]<br></a>
    <a href="../BIT608-AS2-SkyReekie/PrivacyPolicy.php" style="font-size: 20px; padding-top: 0px; line-height: 2;">[Privacy Policy]<br></a>
</body>